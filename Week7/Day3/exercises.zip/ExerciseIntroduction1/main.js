let addressNumber = 55;
let addressStreet = "av Bosquet";
let country = "Paris";

let globalAdress = "I live in ".concat(
  addressNumber,
  " ",
  addressStreet,
  ", in ",
  country,
  ".",
);
console.log(globalAdress);
